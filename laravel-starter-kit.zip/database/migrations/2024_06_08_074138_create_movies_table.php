<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('movies', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('unique_id');
            $table->date('release_year');
            $table->string('length');
            $table->string('language');
            $table->string('quantity');
            $table->string('category');
            $table->string('director');
            $table->string('main_actress');
            $table->string('main_actor');
            $table->text('description');
            $table->string('thumbnail')->nullable();
            $table->timestamps();
        });
    }
    

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('movies');
    }
};
